import { Outlet } from 'react-router'
import Header from './Header'

export default function Layout() {
  return (
    <div className="app-shell">
      <Header />
      <main className="page-content">
        <Outlet />
      </main>
      <footer>Напоминалка · Учебный проект на React</footer>
    </div>
  )
}
