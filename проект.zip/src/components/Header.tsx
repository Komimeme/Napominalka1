import { NavLink, Link } from 'react-router'

export default function Header() {
  return (
    <header className="topbar">
      <Link className="brand" to="/">
        <span className="brand-icon">✓</span>
        <span>Напоминалка</span>
      </Link>
      <nav className="navigation">
        <NavLink to="/" end>Главная</NavLink>
        <NavLink to="/tasks">Мои задачи</NavLink>
        <NavLink to="/tasks/new">Новая задача</NavLink>
        <NavLink to="/analytics">Аналитика</NavLink>
        <NavLink to="/calendar">Календарь</NavLink>
      </nav>
      <div className="profile">
        <span className="profile-avatar">П</span>
        <span>Мой план</span>
      </div>
    </header>
  )
}
