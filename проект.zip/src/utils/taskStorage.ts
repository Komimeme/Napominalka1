import { mockTasks } from '../mocks/mockTasks'
import type { TaskItem } from '../types/task'

export const STORAGE_KEY = 'napominalka-tasks'

export function readTasks(): TaskItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw) as TaskItem[]
  } catch {
    // Если хранилище повреждено, используем исходные демонстрационные задачи.
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(mockTasks))
  return mockTasks
}

export function writeTasks(tasks: TaskItem[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks))
  window.dispatchEvent(new Event('tasks-updated'))
}
