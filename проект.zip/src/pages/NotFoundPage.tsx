import { Link } from 'react-router'
export default function NotFoundPage() {
  return <section className="not-found"><h1>Страница не найдена</h1><p>По адресу, который вы открыли, ничего нет.</p><Link to="/" className="add-task-button">На главную</Link></section>
}
