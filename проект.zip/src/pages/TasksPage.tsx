import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import TaskCard from '../components/TaskCard'
import type { TaskItem } from '../types/task'
import { readTasks, writeTasks } from '../utils/taskStorage'

export default function TasksPage() {
  const [tasks, setTasks] = useState<TaskItem[]>([])
  const [filter, setFilter] = useState('Все')
  useEffect(() => { const update=()=>setTasks(readTasks()); update(); window.addEventListener('tasks-updated',update); return ()=>window.removeEventListener('tasks-updated',update) }, [])
  function toggleTask(id: string) {
    const updated=tasks.map(task=>task.id===id?{...task,isCompleted:!task.isCompleted,status:!task.isCompleted?'Выполнено' as const:'Новая' as const}:task)
    setTasks(updated); writeTasks(updated)
  }
  function deleteTask(id: string) {
    const task=tasks.find(t=>t.id===id)
    if (!task || !window.confirm(`Удалить задачу «${task.title}»?`)) return
    const updated=tasks.filter(t=>t.id!==id); setTasks(updated); writeTasks(updated)
  }
  const visible=filter==='Все'?tasks:filter==='Просроченные'?tasks.filter(t=>!t.isCompleted&&t.status!=='Выполнено'&&t.dueDate<new Date().toISOString().slice(0,10)):tasks.filter(t=>t.status===filter)
  return <section className="route-page">
    <div className="route-page-heading"><div><span className="eyebrow">ПЛАНИРОВАНИЕ</span><h1>Мои задачи</h1><p>Полный список дел. Здесь можно отмечать, редактировать и удалять задачи.</p></div><Link className="add-task-button" to="/tasks/new">＋ Новая задача</Link></div>
    <div className="task-filters">{['Все','Новая','В работе','Выполнено','Отложено','Просроченные'].map(v=><button key={v} className={filter===v?'filter-active':''} onClick={()=>setFilter(v)}>{v}</button>)}</div>
    {visible.length ? <div className="route-task-list">{visible.map(task=><div className="task-list-entry" key={task.id}><TaskCard task={task} onToggle={toggleTask}/><div className="task-entry-actions"><Link to={`/tasks/${task.id}`}>Открыть →</Link><Link to={`/tasks/${task.id}/edit`}>Редактировать</Link><button onClick={()=>deleteTask(task.id)}>Удалить</button></div></div>)}</div> : <p>Задач в этой категории нет. <Link to="/tasks/new">Создать задачу</Link></p>}
  </section>
}
