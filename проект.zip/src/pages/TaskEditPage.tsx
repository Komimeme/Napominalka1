import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import type { Category, Priority, Status, TaskItem } from '../types/task'
import { readTasks, writeTasks } from '../utils/taskStorage'

export default function TaskEditPage() {
  const { taskId } = useParams()
  const navigate = useNavigate()
  const [task, setTask] = useState<TaskItem | undefined>()
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState<Category>('Учёба')
  const [status, setStatus] = useState<Status>('Новая')
  const [priority, setPriority] = useState<Priority>('Средний')
  const [dueDate, setDueDate] = useState('')
  const [hours, setHours] = useState('1')

  useEffect(() => {
    const found = readTasks().find(item => item.id === taskId)
    setTask(found)
    if (found) {
      setTitle(found.title); setDescription(found.description); setCategory(found.category)
      setStatus(found.status); setPriority(found.priority); setDueDate(found.dueDate)
      setHours(String(found.estimatedHours))
    }
  }, [taskId])

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!task) return
    const updated = readTasks().map(item => item.id === task.id ? {
      ...item, title: title.trim(), description: description.trim(), category, status,
      priority, dueDate, estimatedHours: Number(hours) || 1, isCompleted: status === 'Выполнено',
    } : item)
    writeTasks(updated)
    navigate(`/tasks/${task.id}`)
  }

  if (!task) return <section className="route-page"><h1>Задача не найдена</h1><Link to="/tasks">← К списку задач</Link></section>

  return <section className="route-page">
    <div className="route-page-heading"><div><span className="eyebrow">УПРАВЛЕНИЕ</span><h1>Редактирование задачи</h1><p>Измените нужные поля и сохраните результат.</p></div></div>
    <form className="task-form route-form" onSubmit={submit}>
      <label className="form-field form-wide">Название задачи<input required value={title} onChange={e => setTitle(e.target.value)} /></label>
      <label className="form-field form-wide">Описание<textarea rows={3} value={description} onChange={e => setDescription(e.target.value)} /></label>
      <label className="form-field">Категория<select value={category} onChange={e => setCategory(e.target.value as Category)}>{['Работа','Личное','Учёба','Дом'].map(v => <option key={v}>{v}</option>)}</select></label>
      <label className="form-field">Статус<select value={status} onChange={e => setStatus(e.target.value as Status)}>{['Новая','В работе','Выполнено','Отложено'].map(v => <option key={v}>{v}</option>)}</select></label>
      <label className="form-field">Приоритет<select value={priority} onChange={e => setPriority(e.target.value as Priority)}>{['Низкий','Средний','Высокий'].map(v => <option key={v}>{v}</option>)}</select></label>
      <label className="form-field">Срок<input type="date" required value={dueDate} onChange={e => setDueDate(e.target.value)} /></label>
      <label className="form-field">Время (часы)<input type="number" min="0.5" step="0.5" value={hours} onChange={e => setHours(e.target.value)} /></label>
      <div className="form-actions form-wide"><Link className="cancel-button" to={`/tasks/${task.id}`}>Отмена</Link><button className="add-task-button" type="submit">Сохранить изменения</button></div>
    </form>
  </section>
}
