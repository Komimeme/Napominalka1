import { Link, useNavigate, useParams } from 'react-router'
import { useEffect, useState } from 'react'
import type { TaskItem } from '../types/task'
import { readTasks, writeTasks } from '../utils/taskStorage'

export default function TaskDetailsPage() {
  const { taskId } = useParams()
  const navigate = useNavigate()
  const [task, setTask] = useState<TaskItem | undefined>()
  useEffect(() => { const update=()=>setTask(readTasks().find(item=>item.id===taskId)); update(); window.addEventListener('tasks-updated',update); return ()=>window.removeEventListener('tasks-updated',update) }, [taskId])
  function removeTask() {
    if (!task || !window.confirm(`Удалить задачу «${task.title}»?`)) return
    writeTasks(readTasks().filter(item=>item.id!==task.id)); navigate('/tasks')
  }
  if (!task) return <section className="route-page"><h1>Задача не найдена</h1><p>Возможно, задача была удалена или ссылка неверна.</p><Link to="/tasks">← К списку задач</Link></section>
  return <section className="route-page"><span className="eyebrow">ПОДРОБНОСТИ</span><h1>{task.title}</h1><p>{task.description}</p><div className="detail-grid"><div><b>Категория</b><span>{task.category}</span></div><div><b>Статус</b><span>{task.status}</span></div><div><b>Приоритет</b><span>{task.priority}</span></div><div><b>Срок</b><span>{new Date(`${task.dueDate}T00:00:00`).toLocaleDateString('ru-RU')}</span></div><div><b>Оценка времени</b><span>{task.estimatedHours} ч.</span></div></div><div className="form-actions"><Link className="cancel-button" to="/tasks">← Все задачи</Link><Link className="add-task-button" to={`/tasks/${task.id}/edit`}>Редактировать</Link><button className="delete-task-button" onClick={removeTask}>Удалить задачу</button></div></section>
}
