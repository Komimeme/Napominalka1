import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router'
import type { TaskItem } from '../types/task'
import { readTasks } from '../utils/taskStorage'

export default function CalendarPage() {
  const [tasks, setTasks] = useState<TaskItem[]>([])
  const [month, setMonth] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1) })
  useEffect(() => { const update=()=>setTasks(readTasks()); update(); window.addEventListener('tasks-updated',update); return ()=>window.removeEventListener('tasks-updated',update) }, [])
  const year=month.getFullYear(), monthIndex=month.getMonth()
  const days=useMemo(()=>{const first=new Date(year,monthIndex,1); const offset=(first.getDay()+6)%7; const count=new Date(year,monthIndex+1,0).getDate(); const cells: (number|null)[]=[...Array(offset).fill(null),...Array.from({length:count},(_,i)=>i+1)]; while(cells.length%7) cells.push(null); return cells},[year,monthIndex])
  const dateKey=(day:number)=>`${year}-${String(monthIndex+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`
  return <section className="route-page"><div className="route-page-heading"><div><span className="eyebrow">РАСПИСАНИЕ</span><h1>Календарь</h1><p>Задачи распределены по датам выполнения.</p></div><div className="calendar-controls"><button className="cancel-button" onClick={()=>setMonth(new Date(year,monthIndex-1,1))}>←</button><b>{month.toLocaleDateString('ru-RU',{month:'long',year:'numeric'})}</b><button className="cancel-button" onClick={()=>setMonth(new Date(year,monthIndex+1,1))}>→</button></div></div>
    <div className="calendar-grid">{['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(d=><div className="calendar-weekday" key={d}>{d}</div>)}{days.map((day,i)=><div className={`calendar-day ${day ? '' : 'calendar-empty'}`} key={i}>{day && <><b>{day}</b><div className="calendar-day-tasks">{tasks.filter(t=>t.dueDate===dateKey(day)).map(t=><Link key={t.id} to={`/tasks/${t.id}`} className={`calendar-task ${t.isCompleted?'calendar-task-done':''}`} title={t.title}>{t.title}</Link>)}</div></>}</div>)}</div>
    <p className="calendar-legend">Нажмите на задачу в календаре, чтобы открыть её карточку.</p><Link to="/tasks">Посмотреть все задачи →</Link>
  </section>
}
