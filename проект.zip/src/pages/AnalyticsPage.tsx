import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import type { TaskItem } from '../types/task'
import { readTasks } from '../utils/taskStorage'

export default function AnalyticsPage() {
  const [tasks, setTasks] = useState<TaskItem[]>([])
  useEffect(() => { const update = () => setTasks(readTasks()); update(); window.addEventListener('tasks-updated', update); return () => window.removeEventListener('tasks-updated', update) }, [])
  const total = tasks.length
  const done = tasks.filter(t => t.isCompleted || t.status === 'Выполнено').length
  const active = tasks.filter(t => t.status === 'В работе').length
  const overdue = tasks.filter(t => !t.isCompleted && t.status !== 'Выполнено' && t.dueDate < new Date().toISOString().slice(0,10)).length
  const categories = ['Работа','Личное','Учёба','Дом'] as const
  const statuses = ['Новая','В работе','Выполнено','Отложено'] as const
  const bar = (label: string, count: number, color: string) => <div className="analytics-row" key={label}><div className="analytics-label"><span>{label}</span><b>{count}</b></div><div className="analytics-track"><div className="analytics-fill" style={{ width: `${total ? count / total * 100 : 0}%`, background: color }} /></div></div>
  return <section className="route-page"><span className="eyebrow">ОБЗОР</span><h1>Аналитика</h1><p>Статистика автоматически обновляется при добавлении, изменении и удалении задач.</p>
    <div className="analytics-summary"><div><strong>{total}</strong><span>Всего задач</span></div><div><strong>{done}</strong><span>Выполнено</span></div><div><strong>{active}</strong><span>В работе</span></div><div><strong>{overdue}</strong><span>Просрочено</span></div></div>
    <div className="analytics-columns"><div className="analytics-panel"><h2>По категориям</h2>{categories.map((v,i)=>bar(v,tasks.filter(t=>t.category===v).length,['#8273df','#e49aaf','#6da9cf','#8ab99a'][i]))}</div><div className="analytics-panel"><h2>По статусам</h2>{statuses.map((v,i)=>bar(v,tasks.filter(t=>t.status===v || (v==='Выполнено' && t.isCompleted)).length,['#8c82d9','#6da9cf','#8ab99a','#e5b46d'][i]))}</div></div>
    <Link to="/tasks">Перейти к задачам →</Link>
  </section>
}
