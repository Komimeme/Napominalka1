import { useState } from 'react'
import type { FormEvent } from 'react'
import { Link, useNavigate } from 'react-router'
import type { Category, Priority, TaskItem } from '../types/task'
import { readTasks, writeTasks } from '../utils/taskStorage'

export default function TaskCreatePage() {
  const navigate = useNavigate()
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState<Category>('Учёба')
  const [priority, setPriority] = useState<Priority>('Средний')
  const [dueDate, setDueDate] = useState('2026-12-01')
  const [hours, setHours] = useState('1')

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const task: TaskItem = { id: `task-${Date.now()}`, title: title.trim(), description: description.trim(), category, status: 'Новая', priority, dueDate, estimatedHours: Number(hours) || 1, isCompleted: false, createdAt: new Date().toISOString() }
    writeTasks([task, ...readTasks()])
    navigate('/tasks')
  }

  return <section className="route-page"><div className="route-page-heading"><div><span className="eyebrow">ПЛАНИРОВАНИЕ</span><h1>Новая задача</h1><p>Заполните информацию и сохраните задачу.</p></div></div>
    <form className="task-form route-form" onSubmit={submit}>
      <label className="form-field form-wide">Название задачи<input required value={title} onChange={e => setTitle(e.target.value)} placeholder="Например, подготовить отчёт" /></label>
      <label className="form-field form-wide">Описание<textarea rows={3} value={description} onChange={e => setDescription(e.target.value)} placeholder="Что нужно сделать?" /></label>
      <label className="form-field">Категория<select value={category} onChange={e => setCategory(e.target.value as Category)}><option>Работа</option><option>Личное</option><option>Учёба</option><option>Дом</option></select></label>
      <label className="form-field">Приоритет<select value={priority} onChange={e => setPriority(e.target.value as Priority)}><option>Низкий</option><option>Средний</option><option>Высокий</option></select></label>
      <label className="form-field">Срок<input type="date" required value={dueDate} onChange={e => setDueDate(e.target.value)} /></label>
      <label className="form-field">Время (часы)<input type="number" min="0.5" step="0.5" value={hours} onChange={e => setHours(e.target.value)} /></label>
      <div className="form-actions form-wide"><Link className="cancel-button" to="/tasks">Отмена</Link><button className="add-task-button" type="submit">Сохранить задачу</button></div>
    </form>
  </section>
}
