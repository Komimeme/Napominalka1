import { useMemo } from 'react';
import { mockTasks } from './data/mockTasks';
import type { TaskItem } from './types/task';

const TODAY = '2026-10-11';

function getTaskStatus(task: TaskItem, today: string): string {
  if (task.isCompleted) return 'Выполнено';
  if (task.dueDate < today) return 'Просрочено';
  if (task.dueDate === today) return 'Сегодня';

  const currentDate = new Date(`${today}T00:00:00`);
  const dueDate = new Date(`${task.dueDate}T00:00:00`);

  const diff = Math.round(
    (dueDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24)
  );

  if (diff <= 3) return 'Скоро';

  return 'Запланировано';
}

function App() {
  const totalTasks = mockTasks.length;

  const completedTasks = mockTasks.filter((task) => task.isCompleted).length;

  const activeTasks = mockTasks.filter((task) => !task.isCompleted);

  const totalHours = activeTasks.reduce(
    (sum, task) => sum + task.estimatedHours,
    0
  );

  const upcomingTasks = useMemo(
    () =>
      activeTasks.filter((task) => {
        const status = getTaskStatus(task, TODAY);
        return status === 'Сегодня' || status === 'Скоро';
      }),
    []
  );

  return (
    <main className="app">
      <header className="header">
        <div>
          <p className="eyebrow">ТВОЙ ЛИЧНЫЙ ПЛАНИРОВЩИК</p>
          <h1>Напоминалка</h1>
          <p className="subtitle">Все твои дела в одном месте.</p>
        </div>

        <div className="today">
          {new Date(`${TODAY}T00:00:00`).toLocaleDateString('ru-RU', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
          })}
        </div>
      </header>

      <section className="stats">
        <article className="stat-card">
          <span>Всего задач</span>
          <strong>{totalTasks}</strong>
        </article>

        <article className="stat-card">
          <span>Активные задачи</span>
          <strong>{activeTasks.length}</strong>
        </article>

        <article className="stat-card">
          <span>Выполнено</span>
          <strong>{completedTasks}</strong>
        </article>

        <article className="stat-card">
          <span>Часов на задачи</span>
          <strong>{totalHours.toLocaleString('ru-RU')}</strong>
        </article>
      </section>

      <section className="upcoming">
        <h2>На сегодня и ближайшие дни</h2>

        {upcomingTasks.length > 0 ? (
          <ul>
            {upcomingTasks.map((task) => (
              <li key={task.id}>
                <span>{task.title}</span>
                <span className="deadline">{getTaskStatus(task, TODAY)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p>На ближайшие дни срочных задач нет.</p>
        )}
      </section>

      <section className="task-section">
        <div className="section-heading">
          <div>
            <h2>Мои задачи</h2>
            <p>Список всех запланированных дел</p>
          </div>
          <span className="task-count">{totalTasks} задач</span>
        </div>

        <div className="task-list">
          {mockTasks.map((task) => {
            const status = getTaskStatus(task, TODAY);

            return (
              <article className="task-card" key={task.id}>
                <div className="task-top">
                  <span className="category">{task.category}</span>
                  <span className={`priority priority-${task.priority}`}>
                    {task.priority} приоритет
                  </span>
                </div>

                <h3>{task.title}</h3>
                <p className="description">{task.description}</p>

                <div className="task-bottom">
                  <span>
                    Срок:{' '}
                    {new Date(`${task.dueDate}T00:00:00`).toLocaleDateString(
                      'ru-RU'
                    )}
                  </span>

                  <span>{task.estimatedHours} ч.</span>
                </div>

                <div className="task-status">
                  <span
                    className={
                      status === 'Просрочено'
                        ? 'status overdue'
                        : status === 'Выполнено'
                        ? 'status completed'
                        : 'status'
                    }
                  >
                    {status}
                  </span>
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </main>
  );
}

export default App;
