export type Category = 'Работа' | 'Личное' | 'Учёба' | 'Дом'
export type Status = 'Новая' | 'В работе' | 'Выполнено' | 'Отложено'
export type Priority = 'Низкий' | 'Средний' | 'Высокий'

export interface TaskItem {
  id: string
  title: string
  description: string
  category: Category
  status: Status
  priority: Priority
  dueDate: string
  estimatedHours: number
  isCompleted: boolean
  createdAt: string
}