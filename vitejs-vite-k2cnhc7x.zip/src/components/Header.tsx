export default function Header() {
  return (
    <header className="topbar">
      <a className="brand" href="/">
        <span className="brand-icon">✓</span>
        <span>Напоминалка</span>
      </a>
      <nav className="navigation">
        <a className="active" href="#overview">Главная</a>
        <a href="#tasks">Мои задачи</a>
      </nav>
      <div className="profile">
        <span className="profile-avatar">П</span>
        <span>Мой план</span>
      </div>
    </header>
  )
}