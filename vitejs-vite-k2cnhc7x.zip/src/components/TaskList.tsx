import type { TaskItem } from '../types/task'
import TaskCard from './TaskCard'

interface TaskListProps {
  tasks: TaskItem[]
  onToggle: (taskId: string) => void
}

export default function TaskList({ tasks, onToggle }: TaskListProps) {
  if (tasks.length === 0) {
    return <div className="empty-state">Задачи не найдены. Добавьте новую задачу или измените поисковый запрос.</div>
  }

  return (
    <div className="task-list">
      {tasks.map((task) => <TaskCard key={task.id} task={task} onToggle={onToggle} />)}
    </div>
  )
}
