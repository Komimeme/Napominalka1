import type { TaskItem } from '../types/task'

interface TaskCardProps {
  task: TaskItem
  onToggle: (taskId: string) => void
}

const priorityClass = {
  Высокий: 'priority-high',
  Средний: 'priority-medium',
  Низкий: 'priority-low',
}

export default function TaskCard({ task, onToggle }: TaskCardProps) {
  const statusClass = task.isCompleted
    ? 'status-done'
    : task.status === 'В работе'
      ? 'status-progress'
      : task.status === 'Отложено'
        ? 'status-paused'
        : 'status-new'

  const date = new Date(`${task.dueDate}T00:00:00`).toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'short',
  })

  return (
    <article className={`task-card ${task.isCompleted ? 'task-completed' : ''}`}>
      <div className="task-main">
        <button
          type="button"
          className={`task-check ${task.isCompleted ? 'checked' : ''}`}
          onClick={() => onToggle(task.id)}
          aria-label={task.isCompleted ? 'Отметить задачу невыполненной' : 'Отметить задачу выполненной'}
          aria-pressed={task.isCompleted}
        >
          {task.isCompleted ? '✓' : ''}
        </button>
        <div className="task-copy">
          <h3>{task.title}</h3>
          <p>{task.description}</p>
          <div className="task-meta">
            <span className="category">{task.category}</span>
            <span className={`status ${statusClass}`}>{task.status}</span>
          </div>
        </div>
      </div>
      <div className="task-side">
        <span className={`priority ${priorityClass[task.priority]}`}>
          {task.priority} приоритет
        </span>
        <span className="task-date">Срок: {date}</span>
        <span className="task-hours">{task.estimatedHours} ч.</span>
      </div>
    </article>
  )
}
