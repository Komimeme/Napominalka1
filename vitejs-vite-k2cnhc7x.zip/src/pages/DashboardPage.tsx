import { useEffect, useMemo, useState } from 'react'
import type { FormEvent } from 'react'
import Header from '../components/Header'
import TaskList from '../components/TaskList'
import { getTasksMock } from '../mocks/mockTasks'
import type { Category, Priority, TaskItem } from '../types/task'

const TODAY = '2026-09-01'
const STORAGE_KEY = 'napominalka-tasks'

const emptyForm = {
  title: '',
  description: '',
  category: 'Личное' as Category,
  priority: 'Средний' as Priority,
  dueDate: TODAY,
  estimatedHours: '1',
}

export default function DashboardPage() {
  const [tasks, setTasks] = useState<TaskItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [query, setQuery] = useState('')
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [form, setForm] = useState(emptyForm)

  useEffect(() => {
    let isActive = true
    const savedTasks = localStorage.getItem(STORAGE_KEY)
    let hasSavedTasks = false

    if (savedTasks) {
      try {
        setTasks(JSON.parse(savedTasks) as TaskItem[])
        setIsLoading(false)
        hasSavedTasks = true
      } catch {
        localStorage.removeItem(STORAGE_KEY)
      }
    }

    if (!hasSavedTasks) {
      getTasksMock().then((data) => {
        if (isActive) {
          setTasks(data)
          setIsLoading(false)
        }
      })
    }

    return () => {
      isActive = false
    }
  }, [])

  useEffect(() => {
    document.title = query ? `Поиск: ${query}` : 'Напоминалка'
  }, [query])

  useEffect(() => {
    if (!isLoading) localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks))
  }, [tasks, isLoading])

  const activeTasks = tasks.filter((task) => !task.isCompleted)
  const completedTasks = tasks.filter((task) => task.isCompleted)
  const overdueTasks = activeTasks.filter((task) => task.dueDate < TODAY)
  const hours = activeTasks.reduce((sum, task) => sum + task.estimatedHours, 0)

  const visibleTasks = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase()
    if (!normalizedQuery) return tasks
    return tasks.filter((task) =>
      `${task.title} ${task.description} ${task.category}`
        .toLowerCase()
        .includes(normalizedQuery),
    )
  }, [tasks, query])

  function toggleTask(taskId: string) {
    setTasks((currentTasks) => currentTasks.map((task) => {
      if (task.id !== taskId) return task
      const isCompleted = !task.isCompleted
      return { ...task, isCompleted, status: isCompleted ? 'Выполнено' : 'Новая' }
    }))
  }

  function addTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const newTask: TaskItem = {
      id: `task-${Date.now()}`,
      title: form.title.trim(),
      description: form.description.trim() || 'Описание не добавлено',
      category: form.category,
      status: 'Новая',
      priority: form.priority,
      dueDate: form.dueDate,
      estimatedHours: Math.max(0.5, Number(form.estimatedHours) || 1),
      isCompleted: false,
      createdAt: new Date().toISOString(),
    }
    setTasks((currentTasks) => [newTask, ...currentTasks])
    setForm(emptyForm)
    setIsFormOpen(false)
  }

  return (
    <div className="app-shell">
      <Header />
      <main className="page-content">
        <section className="welcome" id="overview">
          <div>
            <div className="eyebrow">ВАШИ ДЕЛА ПОД КОНТРОЛЕМ</div>
            <h1>Добро пожаловать!</h1>
            <p>Планируйте задачи, следите за сроками и освобождайте время для важного.</p>
          </div>
          <div className="welcome-art" aria-hidden="true">
            <div className="art-circle">✓</div>
            <span className="art-star star-one">✦</span>
            <span className="art-star star-two">✧</span>
          </div>
        </section>

        <section className="stats-grid" aria-label="Статистика задач">
          <div className="stat-card">
            <span className="stat-icon icon-purple">▤</span>
            <span className="stat-label">Всего задач</span>
            <strong>{isLoading ? '—' : tasks.length}</strong>
            <small>Все записи в списке</small>
          </div>
          <div className="stat-card">
            <span className="stat-icon icon-blue">◷</span>
            <span className="stat-label">Активные</span>
            <strong>{isLoading ? '—' : activeTasks.length}</strong>
            <small>Ещё предстоит выполнить</small>
          </div>
          <div className="stat-card">
            <span className="stat-icon icon-green">✓</span>
            <span className="stat-label">Выполнено</span>
            <strong>{isLoading ? '—' : completedTasks.length}</strong>
            <small>Уже сделано</small>
          </div>
          <div className="stat-card">
            <span className="stat-icon icon-orange">!</span>
            <span className="stat-label">Просрочено</span>
            <strong>{isLoading ? '—' : overdueTasks.length}</strong>
            <small>Требуют внимания</small>
          </div>
        </section>

        <section className="content-grid">
          <div className="tasks-panel" id="tasks">
            <div className="section-heading">
              <div>
                <h2>Мои задачи</h2>
                <p>Все дела в одном месте</p>
              </div>
              <span className="task-count">{isLoading ? '...' : `${visibleTasks.length} задач`}</span>
            </div>

            <div className="task-toolbar">
              <label className="search-box">
                <span>⌕</span>
                <input
                  type="search"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Поиск по задачам..."
                />
              </label>
              <button className="add-task-button" type="button" onClick={() => setIsFormOpen((open) => !open)}>
                <span>＋</span> Новая задача
              </button>
            </div>

            {isFormOpen && (
              <form className="task-form" onSubmit={addTask}>
                <h3>Добавить задачу</h3>
                <label className="form-field form-wide">
                  Название задачи
                  <input required maxLength={80} value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="Например, подготовить отчёт" />
                </label>
                <label className="form-field form-wide">
                  Описание
                  <textarea rows={2} maxLength={240} value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} placeholder="Что нужно сделать?" />
                </label>
                <label className="form-field">
                  Категория
                  <select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value as Category })}>
                    <option>Работа</option><option>Личное</option><option>Учёба</option><option>Дом</option>
                  </select>
                </label>
                <label className="form-field">
                  Приоритет
                  <select value={form.priority} onChange={(event) => setForm({ ...form, priority: event.target.value as Priority })}>
                    <option>Низкий</option><option>Средний</option><option>Высокий</option>
                  </select>
                </label>
                <label className="form-field">
                  Срок
                  <input type="date" required value={form.dueDate} onChange={(event) => setForm({ ...form, dueDate: event.target.value })} />
                </label>
                <label className="form-field">
                  Время (часы)
                  <input type="number" min="0.5" max="100" step="0.5" value={form.estimatedHours} onChange={(event) => setForm({ ...form, estimatedHours: event.target.value })} />
                </label>
                <div className="form-actions form-wide">
                  <button className="cancel-button" type="button" onClick={() => { setIsFormOpen(false); setForm(emptyForm) }}>Отмена</button>
                  <button className="add-task-button" type="submit">Добавить задачу</button>
                </div>
              </form>
            )}

            {isLoading ? (
              <div className="loading-state"><span className="loader" /><span>Загрузка...</span></div>
            ) : (
              <TaskList tasks={visibleTasks} onToggle={toggleTask} />
            )}
          </div>

          <aside className="side-column">
            <div className="side-card focus-card">
              <div className="side-card-title"><span className="side-icon">◷</span><h3>Время на задачи</h3></div>
              <strong className="hours-number">{isLoading ? '—' : `${hours.toLocaleString('ru-RU')} ч.`}</strong>
              <p>Примерная оценка времени на все активные задачи.</p>
            </div>
            <div className="side-card">
              <div className="side-card-title"><span className="side-icon purple">✦</span><h3>Небольшой совет</h3></div>
              <p className="tip-text">Начните с самой важной задачи. Даже небольшой шаг приближает вас к результату.</p>
            </div>
            <div className="side-card category-card">
              <h3>Категории</h3>
              <div className="category-row"><span><i className="dot work" />Работа</span><b>{tasks.filter(t => t.category === 'Работа').length}</b></div>
              <div className="category-row"><span><i className="dot study" />Учёба</span><b>{tasks.filter(t => t.category === 'Учёба').length}</b></div>
              <div className="category-row"><span><i className="dot personal" />Личное</span><b>{tasks.filter(t => t.category === 'Личное').length}</b></div>
              <div className="category-row"><span><i className="dot home" />Дом</span><b>{tasks.filter(t => t.category === 'Дом').length}</b></div>
            </div>
          </aside>
        </section>
        <footer>Напоминалка · Учебный проект на React</footer>
      </main>
    </div>
  )
}
